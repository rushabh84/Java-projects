/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import javax.servlet.RequestDispatcher;

/**
 *
 * @author Rush
 */
public class ComputeHashes extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {
        String encrypt = request.getParameter("word");  //gets the word to be encrypted
        String option = request.getParameter("hashing");
        String nextView;
        String afterencryptionhex = "";
        String afterencryptionbase = "";
        if (encrypt != null) {
            MessageDigest messageDigest;
            try {
                if (option.equals("MD5")) {  //checks which hashing to be done
                    messageDigest = MessageDigest.getInstance("MD5");
                } else {
                    messageDigest = MessageDigest.getInstance("SHA-1");  //depending on the hashing option selectd, create an instance of that hashing
                }
                messageDigest.update(encrypt.getBytes());  //Updates the digest using the ByteBuffer of encrypt
                byte[] messageDigestMD5 = messageDigest.digest();  //returns a byte array representation of the messagedigest 
                afterencryptionhex = javax.xml.bind.DatatypeConverter.printHexBinary(messageDigestMD5);  //converts the byte array into hexadecimal encoding
                afterencryptionbase = javax.xml.bind.DatatypeConverter.printBase64Binary(messageDigestMD5);  //converts the byte array into Base-64 encoding
            } catch (NoSuchAlgorithmException exception) {
                // TODO Auto-generated catch block
            }
            processRequest(request, response, afterencryptionhex, afterencryptionbase);
        }
    }

    protected void processRequest(HttpServletRequest request, HttpServletResponse response, String passed, String base)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Result page</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>The hashed value of the word " + request.getParameter("word") + "</h1>");
            out.println("<h3>" + request.getParameter("hashing") + " : (Hex):" + passed + "</h3>");
            out.println("<h3>" + request.getParameter("hashing") + " : (Base 64):" + base + "</h3>");
            out.println("</body>");
            out.println("</html>");
        }
    }

}
