package Project1Task2;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

/**
 *
 * @author Rush
 */
public class IOTProductModel {

    int i;
    private String pictureTag;
    private String pictureURL;
    String[] pUrl;//=new String[100]; 
    String[] pTitle;//=new String[100];
    String[] pDescription;//=new String[100];
    String[] pImage;//= new String[100];

    public void doIOTsearch(String searchproduct) throws UnsupportedEncodingException {
        i = 0;

        pUrl = new String[100];
        pTitle = new String[100];
        pDescription = new String[100];
        pImage = new String[100];
        pictureTag = searchproduct;
        searchproduct = URLEncoder.encode(searchproduct, "UTF-8");
        //Creating a URL for the page to be screen scraped
        String response = "";
        String IotURL = "http://iotlist.co/search?utf8=%E2%9C%93&terms=" + searchproduct;
        response = fetch(IotURL);  //fetching the HTLM response from server 
        System.out.println(response);
        //using cutLeft and cutRight we are parsing through the HTML returned by the server
        //and extract the title, image and description of all the products for the word searched
        int cutLeft = 0;
        int cutRight = 0;
        int pos = response.lastIndexOf("a class=\"link title\"");
        int last = response.indexOf("</p>", pos);
        //while (cutRight < response.lastIndexOf("</p>"))
        while (cutRight < last) //since the length of </p> is 4, so repeat the loop till we reach that index of the last description
        {
            cutLeft = response.indexOf("a class=\"link title\"", cutRight);  //finds the index of the first product's url
            if (cutLeft == -1) {
                pictureURL = pictureTag = null;
                return;
            }
            cutLeft += "a class=\"link title\" href=\"".length();  //extracts the hyperlink for the product from the HTML file stored in response
            cutRight = response.indexOf("\">", cutLeft);
            pUrl[i] = response.substring(cutLeft, cutRight);  //storing all the URLs of products in pUrl array
            System.out.println(i + ": " + pUrl[i]);
            cutLeft = response.indexOf("<h2>", cutRight);  //search for <h2> from the end index of the URL
            cutLeft += "<h2>".length();
            cutRight = response.indexOf("</h2>", cutLeft);
            pTitle[i] = response.substring(cutLeft, cutRight);
            cutLeft = response.indexOf("http:", cutRight);  //extracts the image corrsponding to the title and stores it in pImage array
            cutRight = response.indexOf("\">", cutLeft);
            pImage[i] = response.substring(cutLeft, cutRight);
            cutLeft = response.indexOf("<p>", cutRight);
            cutLeft += "<p>".length();
            cutRight = response.indexOf("</p>", cutLeft);
            pDescription[i] = response.substring(cutLeft, cutRight);  //extracts the description corrsponding to the title and stores it in pImage array
            i += 1;
        }

    }

    public String[] getPictureImage() {
        return pImage;
    }

    public String[] getPictureTitle() {
        return pTitle;
    }

    public String[] getPictureDescription() {
        return pDescription;
    }

    public String[] getProductUrl() {
        //return productUrl;
        return pUrl;
    }

    public int getCount() {
        return i;
    }

    private String fetch(String urlString) {
        String response = "";
        try {
            URL url = new URL(urlString);
            /*
             * Create an HttpURLConnection.  This is useful for setting headers
             * and for getting the path of the resource that is returned (which 
             * may be different than the URL above if redirected).
             * HttpsURLConnection (with an "s") can be used if required by the site.
             */
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            // Read all the text returned by the server
            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"));
            String str;    // Read each line of "in" until done, adding each to "response"
            while ((str = in.readLine()) != null) {
                // str is one line of text readLine() strips newline characters
                response += str;
            }
            in.close();

        } catch (IOException e) {
            System.out.println("Eeek, an exception");
        }
        return response;
    }
}
