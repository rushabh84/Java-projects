package Project1Task2;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Rush
 */

@WebServlet(name = "IOTProductSearch",
        urlPatterns = {"/getAnInterestingProduct"})
public class IOTProductSearch extends HttpServlet{

    
    IOTProductModel iotm;

    public IOTProductSearch() {
        this.iotm = null;
    }
    @Override
    public void init() {
        iotm = new IOTProductModel();
    }
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
            String find = request.getParameter("searchproduct");  // get the search parameter if it exists
            System.out.println("product is: "+find);
            String ua = request.getHeader("User-Agent");  // determine what type of device our user is
            
            String nextView;
                if(find != null)  //if the user enters a search word do webscraping and set of attributes and the view you want to display
                {
                    iotm.doIOTsearch(find);  //passing control to the doProductSearch method of model and choose final view
                    request.setAttribute("pimage", iotm.getPictureImage());
                    request.setAttribute("title", iotm.getPictureTitle());
                    request.setAttribute("describe", iotm.getPictureDescription());
                    request.setAttribute("portal", iotm.getProductUrl());
                    request.setAttribute("find", find);  // set the word we are finding on the jsp page
                    request.setAttribute("count", iotm.getCount());  //count is to store how many products forthe searchword are
                    System.out.println(iotm.getCount());
                    nextView = "final.jsp";
                }
                else
                {
                    nextView="start.jsp";
                }
                RequestDispatcher view = request.getRequestDispatcher(nextView);  //calls the jsp page depending on the condition
                view.forward(request, response); 
            
    }

    
}
