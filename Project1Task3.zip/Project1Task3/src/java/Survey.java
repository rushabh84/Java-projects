import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "Survey",
        urlPatterns = {"/submit", "/getResults"})
public class Survey extends HttpServlet {

    SurveyModel sm;

    public Survey() {
        this.sm = null;
    }

    @Override
    public void init() {
        sm = new SurveyModel();
    }
/**
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String uPath = request.getServletPath();
        String ua = request.getHeader("User-Agent");
        boolean mobile;
        // prepare the appropriate DOCTYPE for the view pages
        if (ua != null && ((ua.indexOf("Android") != -1) || (ua.indexOf("iPhone") != -1))) {
            mobile = true;
            request.setAttribute("doctype", "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.2//EN\" \"http://www.openmobilealliance.org/tech/DTD/xhtml-mobile12.dtd\">");
        } else {
            mobile = false;
            request.setAttribute("doctype", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">");
        }
        String nextView = "";
        if (uPath.equals("/submit")) {
            nextView = "survey.jsp";
        } else {
            if (sm.storedCounts() == null) {  //this if condition handles the part when you refresh 
                //getResults page and checks if the list is null, if null then return count as zero
                //and prints another result
                request.setAttribute("count", 0);  
                nextView = "finalcount.jsp";  
            } else {
                System.out.println(sm.storedCounts().size());
                //if the list counts isnt null, sends the count and the list to jsp page to display the desired result
                request.setAttribute("count", sm.storedCounts().size());
                request.setAttribute("sumedup", sm.storedCounts());
                sm.makeNull();  
                nextView = "finalcount.jsp";
            }
        }
        RequestDispatcher view = request.getRequestDispatcher(nextView);
        view.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String uPath = request.getServletPath();
        System.out.println("The path is: " + uPath);
        String answer = request.getParameter("options");  // determine what type of device our user is
        String ua = request.getHeader("User-Agent");
        boolean mobile;
        // prepare the appropriate DOCTYPE for the view pages
        if (ua != null && ((ua.indexOf("Android") != -1) || (ua.indexOf("iPhone") != -1))) {
            mobile = true;
            request.setAttribute("doctype", "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.2//EN\" \"http://www.openmobilealliance.org/tech/DTD/xhtml-mobile12.dtd\">");
        } else {
            mobile = false;
            request.setAttribute("doctype", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">");
        }
        String nextView;
        //if (answer != null) {
        sm.storeAnswers(answer);
        request.setAttribute("choice", sm.getCurrentValue());
        nextView = "reply.jsp";
        RequestDispatcher view = request.getRequestDispatcher(nextView);
        view.forward(request, response);

        }

}
