import java.util.ArrayList;
import java.util.List;

public class SurveyModel {

    List store = new ArrayList();
    String currentoption;  //stores the radio button selected
    int c = 0, d = 0, a = 0, b = 0;
    List counts;  //stores the count for how many times an option was selected

    public void storeAnswers(String selected) {
        currentoption = selected;
        counts = new ArrayList();
        store.add(selected);
        if (currentoption.equals("A")) {  //this if-else checks which option was selected and accordingly
            a++;                          //increments the count
        } else if (currentoption.equals("B")) {
            b++;  
        } else if (currentoption.equals("C")) {
            c++;
        } else {
            d++;
        }
        counts.add(a);  //adds the count corresponding to each option in this list, handles the alphabetical order
        counts.add(b);
        counts.add(c);
        counts.add(d);
    }

    public String getCurrentValue() {
        return currentoption;  //returns option selected
    }

    public List storedCounts() {
        return counts;  //returns the list which has the counts for all the options in alphabteical order
    }

    public void makeNull() {  //this method makes all the counts and list null once getResults is chosen
        counts = null;
        a = 0;
        b = 0;
        c = 0;
        d = 0;
    }

}
